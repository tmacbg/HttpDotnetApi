﻿using System;
namespace HttpApi.Models
{
    public class RequestModel
    {
        public string url { get; set; }
        public string selector { get; set; }
        public string country { get; set; }
    }
}
